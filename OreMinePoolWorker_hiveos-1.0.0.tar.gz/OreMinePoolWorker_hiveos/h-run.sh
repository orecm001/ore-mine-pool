#!/usr/bin/env bash

source h-manifest.conf
source /hive/miners/custom/OreMinePoolWorker_hiveos/ore.conf

if dpkg -s libc6 | grep Version  | grep -q "2.35"; then
  echo "libc6 found"
else
  echo "update libc6"
  echo "deb http://mirrors.aliyun.com/ubuntu jammy main" >> /etc/apt/sources.list
  apt update
  DEBIAN_FRONTEND=noninteractive apt install libc6 -y 
fi

if ldconfig -p|grep ssl | grep -q "libssl.so.3"; then
  echo "ssl3 found"
else
  echo "update ssl3"
  echo "deb http://mirrors.aliyun.com/ubuntu jammy main" >> /etc/apt/sources.list 
  apt update
  DEBIAN_FRONTEND=noninteractive apt install libssl-dev -y 
fi

./ore-mine-pool-linux worker --server-url $SERVER_URL --worker-wallet-address $WALLET_ADDRESS $EXTRA 2>&1 | tee --append $MINER_LOG_BASENAME.log
